pub type c_char = u8;
pub type wchar_t = u32;

pub type c_long = i64;
pub type c_ulong = u64;
