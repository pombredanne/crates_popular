// Copyright © 2017 winapi-rs developers
// Licensed under the Apache License, Version 2.0
// <LICENSE-APACHE or http://www.apache.org/licenses/LICENSE-2.0> or the MIT license
// <LICENSE-MIT or http://opensource.org/licenses/MIT>, at your option.
// All files in the project carrying such notice may not be copied, modified, or distributed
// except according to those terms.
DEFINE_GUID!{CLSID_DxDiagProvider,
    0xa65b8071, 0x3bfe, 0x4213, 0x9a, 0x5b, 0x49, 0x1d, 0xa4, 0x46, 0x1c, 0xa7}
DEFINE_GUID!{IID_IDxDiagProvider,
    0x9c6b4cb0, 0x23f8, 0x49cc, 0xa3, 0xed, 0x45, 0xa5, 0x50, 0x00, 0xa6, 0xd2}
DEFINE_GUID!{IID_IDxDiagContainer,
    0x7d0f462f, 0x4064, 0x4862, 0xbc, 0x7f, 0x93, 0x3e, 0x50, 0x58, 0xc1, 0x0f}
